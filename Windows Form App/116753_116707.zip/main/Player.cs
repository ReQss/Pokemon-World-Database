﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace main
{
    public partial class Player : Form
    {
        String path = @"Data Source=DESKTOP-NF4M5AI\SQLEXPRESS;Initial Catalog=Poke2;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        DataTable tab;
        SqlDataAdapter adpt;
        public Player()
        {
            InitializeComponent();
            con = new SqlConnection(path);
            display();
            displayHand();
            fillId();
            fillIdPoke();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        void display() {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * FROM displayPlayer", con);
                adpt.Fill(tab);
                dataGridView1.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void displayHand()
        {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * FROM displayHand", con);
                adpt.Fill(tab);
                dataGridView2.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("InsertPlayerHand", con);
                cmd.CommandType = CommandType.StoredProcedure;
                // Add parameter values
                cmd.Parameters.AddWithValue("@playerId", listBox5.Text);
                cmd.Parameters.AddWithValue("@pokemonId", listBox4.Text);
                cmd.Parameters.AddWithValue("@pokeLevel", textBox3.Text);
                cmd.Parameters.AddWithValue("@evolutionStage", 1); 
                cmd.Parameters.AddWithValue("@relation", "bad"); 
                cmd.Parameters.AddWithValue("@moveId", 1); 
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Pokemon added to inventory");
                display();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void search_Click(object sender, EventArgs e)
        {
            if (listBox1.Text == "Name and surname")
            {
                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * FROM displayPlayer WHERE fname = '" + textBox1.Text + "' AND lname = '" + textBox2.Text + "'", con);
                    adpt.Fill(tab);
                    dataGridView1.DataSource = tab;
          
                    con.Close();
                    SearchPlayerInventoryName();
                    MessageBox.Show("Searching done");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            
            else
            {
                display();
                displayHand();
            }
        }
        void SearchPlayerInventoryName()
        {
            
            try
            {
                tab = new DataTable();
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT DISTINCT * FROM displayInventory INNER JOIN PLAYER_HAND ON PLAYER_HAND.pokemon_id = displayInventory.pokemon_id INNER JOIN PEOPLE ON PEOPLE.player_id = PLAYER_HAND.player_id WHERE PEOPLE.fname = @fname AND PEOPLE.lname = @lname", con);
                cmd.Parameters.AddWithValue("@fname", textBox1.Text);
                cmd.Parameters.AddWithValue("@lname", textBox2.Text);
                adpt = new SqlDataAdapter(cmd);
                adpt.Fill(tab);
                dataGridView2.DataSource = tab;
               
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void fillId()
        {
            try
            {
                con.Open();
                string query = "SELECT  player_id FROM players";
                SqlCommand command = new SqlCommand(query, con);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                
                listBox5.DataSource = dataTable;
                listBox5.DisplayMember = "player_id";
                listBox2.DataSource = dataTable;
                listBox2.DisplayMember = "player_id";
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void fillIdPoke()
        {
            try
            {
                con.Open();
                string query = "SELECT  pokemon_id FROM pokemons";
                SqlCommand command = new SqlCommand(query, con);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                listBox4.DataSource = dataTable;
                listBox4.DisplayMember = "pokemon_id";
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("DeletePlayerHand", con);
                cmd.CommandType = CommandType.StoredProcedure;

                // Add parameter values
                cmd.Parameters.AddWithValue("@playerId", listBox2.Text);
                cmd.Parameters.AddWithValue("@pokemonId", listBox4.Text);

                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Pokemon deleted from inventory");
                display();
                fillId();
                fillIdPoke();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void listBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
