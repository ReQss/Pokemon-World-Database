﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace main
{
    public partial class Gym : Form
    {
        String path = @"Data Source=DESKTOP-NF4M5AI\SQLEXPRESS;Initial Catalog=Poke2;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        DataTable tab;
        SqlDataAdapter adpt;
        public Gym()
        {
            InitializeComponent();
            con = new SqlConnection(path);
            display();
            fillTypes();
            fillLeadersId();
            fillGymId();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        void display() {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * FROM displayGym2", con);
                adpt.Fill(tab);
                dataGridView1.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Empty data");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("InsertIntoGyms", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Name", textBox1.Text);
                    cmd.Parameters.AddWithValue("@BadgeName", textBox3.Text);
                    cmd.Parameters.AddWithValue("@Type", listBox1.Text);
                    cmd.Parameters.AddWithValue("@LeaderId", Convert.ToInt32(listBox2.Text));

                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Gym added");
                    display();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            if (listBox3.Text == "")
            {
                MessageBox.Show("No data to delete");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("DeleteGym", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@GymId", Convert.ToInt32(listBox3.Text));

                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Gym deleted");
                    display();
                    fillGymId();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void update_Click(object sender, EventArgs e)
        {
            if (listBox3.Text == "")
            {
                MessageBox.Show("No id given");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("UpdateGym", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@GymId", Convert.ToInt32(listBox3.Text));
                    cmd.Parameters.AddWithValue("@Name", textBox1.Text);
                    cmd.Parameters.AddWithValue("@BadgeName", listBox1.Text);
                    cmd.Parameters.AddWithValue("@Type", listBox1.Text);
                    cmd.Parameters.AddWithValue("@LeaderId", Convert.ToInt32(listBox2.Text));

                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Gym updated");
                    display();
                    fillGymId();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void search_Click(object sender, EventArgs e)
        {

            if (listBox5.Text == "List All")
            {
                display();
            }
            else if (listBox5.Text =="Gym name")
            {
                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * FROM displayGym2 WHERE displayGym2.name = '" + textBox1.Text + "'", con);
                    adpt.Fill(tab);
                    dataGridView1.DataSource = tab;
                    MessageBox.Show("Searching done");
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (listBox5.Text == "Type")
            {
                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * FROM displayGym2 WHERE displayGym2.type = '" + listBox1.Text + "'", con);
                    adpt.Fill(tab);
                    dataGridView1.DataSource = tab;
                    MessageBox.Show("Searching done");
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if(listBox5.Text=="Leader name")
            {
                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * FROM displayGym2 WHERE displayGym2.leader = '" + listBox1.Text + "'", con);
                    adpt.Fill(tab);
                    dataGridView1.DataSource = tab;
                    MessageBox.Show("Searching done");
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * FROM displayGym2 WHERE displayGym2.City name = '" + listBox1.Text + "'", con);
                    adpt.Fill(tab);
                    dataGridView1.DataSource = tab;
                    MessageBox.Show("Searching done");
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void sort_Click(object sender, EventArgs e)
        {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * from displayGym2 ORDER BY name ", con);
                adpt.Fill(tab);
                dataGridView1.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        void fillTypes()
        {
            try
            {
                con.Open();
                string query = "SELECT  type_name FROM types";
                SqlCommand command = new SqlCommand(query, con);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                listBox1.DataSource = dataTable;
                listBox1.DisplayMember = "type_name";
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void fillLeadersId()
        {
            try
            {
                con.Open();
                string query = "SELECT leader_id FROM LEADERS;";
                SqlCommand command = new SqlCommand(query, con);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                listBox2.DataSource = dataTable;
                listBox2.DisplayMember = "leader_id";
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void fillGymId()
        {
            try
            {
                con.Open();
                string query = "SELECT gym_id FROM gyms;";
                SqlCommand command = new SqlCommand(query, con);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                listBox3.DataSource = dataTable;
                listBox3.DisplayMember = "gym_id";
                listBox4.DataSource = dataTable;
                listBox4.DisplayMember = "gym_id";
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void listBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
