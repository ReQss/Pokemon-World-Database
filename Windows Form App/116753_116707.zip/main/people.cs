﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace main
{
    public partial class people : Form
    {
        String path = @"Data Source=DESKTOP-NF4M5AI\SQLEXPRESS;Initial Catalog=Poke2;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        DataTable tab;
        SqlDataAdapter adpt;
        public people()
        {
            InitializeComponent();
            con = new SqlConnection(path);
            display();
            fillPlayerId();
            fillpeopleId();
            fillleaderId();
        }

        private void people_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            display();
        }
        void display() {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * from displayPeople", con);
                adpt.Fill(tab);
                dataGridView1.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Empty data");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("InsertPerson", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@FirstName", textBox1.Text);
                    cmd.Parameters.AddWithValue("@LastName", textBox2.Text);
                    cmd.Parameters.AddWithValue("@Phone", textBox3.Text);
                    cmd.Parameters.AddWithValue("@Address", textBox4.Text);
                    cmd.Parameters.AddWithValue("@PlayerId", Convert.ToInt32(listBox1.Text));
                    cmd.Parameters.AddWithValue("@LeaderId", Convert.ToInt32(listBox5.Text));

                    cmd.ExecuteNonQuery();
                    fillleaderId();
                    fillPlayerId();
                    fillpeopleId();
                    con.Close();

                    MessageBox.Show("Person added");
                    display();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void delete_Click(object sender, EventArgs e)
        {
            if (listBox2.Text == "")
            {
                MessageBox.Show("No data to delete");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("DeletePerson", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PersonId", Convert.ToInt32(listBox2.Text));

                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Person deleted");
                    display();
                    fillpeopleId();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void update_Click(object sender, EventArgs e)
        {
            if (listBox2.Text == "")
            {
                MessageBox.Show("No id given");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("UpdatePerson", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PersonId", Convert.ToInt32(listBox2.Text));
                    cmd.Parameters.AddWithValue("@FirstName", textBox1.Text);
                    cmd.Parameters.AddWithValue("@LastName", textBox2.Text);
                    cmd.Parameters.AddWithValue("@Phone", textBox3.Text);
                    cmd.Parameters.AddWithValue("@Address", textBox4.Text);
                    cmd.Parameters.AddWithValue("@PlayerId", Convert.ToInt32(listBox1.Text));

                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Person updated");
                    display();
                    fillpeopleId();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void search_Click(object sender, EventArgs e)
        {
            if (listBox4.Text == "Name and last name")
            {

                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * FROM displayPeople WHERE displayPeople.fname = '" + textBox1.Text + "' AND displayPeople.lname = '" + textBox2.Text + "'", con);
                    adpt.Fill(tab);
                    dataGridView1.DataSource = tab;
                    MessageBox.Show("Searching done");
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (listBox4.Text == "Leader id") {
                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * FROM displayPeople WHERE displayPeople.leader_id = '" + listBox5.Text + "'", con);
                    adpt.Fill(tab);
                    dataGridView1.DataSource = tab;
                    MessageBox.Show("Searching done");
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (listBox4.Text =="Player id") {
                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * FROM displayPeople WHERE displayPeople.player_id = '" + listBox1.Text + "'", con);
                    adpt.Fill(tab);
                    dataGridView1.DataSource = tab;
                    MessageBox.Show("Searching done");
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                display();
            }
        }

        private void sort_Click(object sender, EventArgs e)
        {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * from displayPeople ORDER BY displayPeople.fname ", con);
                adpt.Fill(tab);
                dataGridView1.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void fillPlayerId()
        {
            try
            {
                con.Open();
                string query = "SELECT * FROM LEADERS;";
                SqlCommand command = new SqlCommand(query, con);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                listBox1.DataSource = dataTable;
                listBox1.DisplayMember = "leader_id";
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void fillpeopleId()
        {
            try
            {
                con.Open();
                string query = "SELECT person_id FROM people;";
                SqlCommand command = new SqlCommand(query, con);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                listBox2.DataSource = dataTable;
                listBox2.DisplayMember = "person_id";
                listBox3.DataSource = dataTable;
                listBox3.DisplayMember = "person_id";
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void fillleaderId()
        {
            try
            {
                con.Open();
                string query = "SELECT leader_id FROM leaders;";
                SqlCommand command = new SqlCommand(query, con);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                listBox5.DataSource = dataTable;
                listBox5.DisplayMember = "leader_id";
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
