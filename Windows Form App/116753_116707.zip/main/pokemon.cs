﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace main
{
    public partial class pokemon : Form
    {
        String path = @"Data Source=DESKTOP-NF4M5AI\SQLEXPRESS;Initial Catalog=Poke2;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        DataTable tab;
        SqlDataAdapter adpt;
       
        public pokemon()
        {
            InitializeComponent();
            con = new SqlConnection(path);
            display();
            fillTypes();
            fillId();
        }

        private void pokemon_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (nameBox.Text == "" || evolutionListBox.Text == "" || typeListBox.Text == "")
            {
                MessageBox.Show("Empty data");
            }
            else
            {
                try
                {
                    con.Open();
                    cmd = new SqlCommand("InsertPokemon", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Name", nameBox.Text);
                    cmd.Parameters.AddWithValue("@Type1", typeListBox.Text);
                    cmd.Parameters.AddWithValue("@Type2", listBox3.Text);
                    cmd.Parameters.AddWithValue("@EvolutionLevel", evolutionListBox.Text);
                    cmd.Parameters.AddWithValue("@Generation", textBox1.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Pokemon added");
                    display();
                    fillId();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void display() {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * from displayPokemons;", con);
                adpt.Fill(tab);
                dataGridView1.DataSource = tab;
                con.Close();
            }
            catch (Exception ex){
                MessageBox.Show(ex.Message);
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            if (listBox1.Text == "")
            {
                MessageBox.Show("No data to delete");
            }
            else
            {
                try
                {
                    con.Open();
                    cmd = new SqlCommand("DeletePokemon", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PokemonId", listBox1.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Pokemon deleted");
                    display();
                    fillId();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void update_Click(object sender, EventArgs e)
        {
            if (listBox1.Text == "")
            {
                MessageBox.Show("No id given");
            }
            else
            {
                try
                {
                    con.Open();
                    cmd = new SqlCommand("UpdatePokemon", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PokemonId", listBox1.Text);
                    cmd.Parameters.AddWithValue("@Name", nameBox.Text);
                    cmd.Parameters.AddWithValue("@Type1", typeListBox.Text);
                    cmd.Parameters.AddWithValue("@Type2", listBox3.Text);
                    cmd.Parameters.AddWithValue("@EvolutionLevel", evolutionListBox.Text);
                    cmd.Parameters.AddWithValue("@Generation", Convert.ToInt32(textBox1.Text));
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Pokemons updated");
                    display();
                    fillId();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void search_Click(object sender, EventArgs e)
        {

            if (listBox4.Text == "name")
            {
                displayByName();
            }
            else if (listBox4.Text == "types")
            {
                displayByTypes();
            }
            else if (listBox4.Text == "evolution")
            {
                displayByEvol();
            }
            else if (listBox4.Text == "generation")
            {
                displayByGen();
            }
            else display();
        }
        void displayByTypes()
        {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * from displayPokemons WHERE type1 = '" + typeListBox.Text + "'AND type2 = '" + listBox3.Text +"'", con);
                adpt.Fill(tab);
                dataGridView1.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void displayByName() {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * from displayPokemons WHERE name = '" + nameBox.Text + "'", con);
                adpt.Fill(tab);
                dataGridView1.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void displayByGen()
        {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * from displayPokemons WHERE generation = '" + textBox1.Text + "'", con);
                adpt.Fill(tab);
                dataGridView1.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void displayByEvol()
        {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * from displayPokemons WHERE evolution_level = '" + evolutionListBox.Text + "'", con);
                adpt.Fill(tab);
                dataGridView1.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void sort_Click(object sender, EventArgs e)
        {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * from displayPokemons ORDER BY name", con);
                adpt.Fill(tab);
                dataGridView1.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void typeListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
        void fillTypes() {
            try
            {
                con.Open();
                string query = "SELECT  * FROM types";
                SqlCommand command = new SqlCommand(query, con);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                typeListBox.DataSource = dataTable;
                typeListBox.DisplayMember = "type_name";
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void fillId()
        {
            try
            {
                con.Open();
                string query = "SELECT pokemon_id FROM pokemons";
                SqlCommand command = new SqlCommand(query, con);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                listBox1.DataSource = dataTable;
                listBox1.DisplayMember = "pokemon_id";
                listBox2.DataSource = dataTable;
                listBox2.DisplayMember = "pokemon_id";
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }

}
