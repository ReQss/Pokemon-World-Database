﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace main
{
    public partial class Form1 : Form
    {
        pokemon pokemon = new pokemon();
        people people = new people();
        Player player = new Player();
        Gym gym = new Gym();
        Locations loc = new Locations();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pokemon.Show();
        }

       

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            people.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            player.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            gym.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            loc.Show();
        }
    }
}
