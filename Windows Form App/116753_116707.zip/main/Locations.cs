﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace main
{
    public partial class Locations : Form
    {
        String path = @"Data Source=DESKTOP-NF4M5AI\SQLEXPRESS;Initial Catalog=Poke2;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        DataTable tab;
        SqlDataAdapter adpt;
        public Locations()
        {
            InitializeComponent();
            con = new SqlConnection(path);
            displayCities();
            displayIslands();
            displayRegions();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        public void displayCities()
        {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * FROM displayCities;", con);
                adpt.Fill(tab);
                dataGridView1.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void displayRegions()
        {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * from displayRegions", con);
                adpt.Fill(tab);
                dataGridView2.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void displayIslands()
        {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * FROM displayIslands;", con);
                adpt.Fill(tab);
                dataGridView3.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void search_Click(object sender, EventArgs e)
        {
            if (nameBox.Text == "")
            {
                displayCities();
            }
            else
            {
                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * FROM displayCities WHERE name = '" + nameBox.Text + "'", con);
                    adpt.Fill(tab);
                    dataGridView1.DataSource = tab;
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                displayRegions();
            }
            else
            {
                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * from displayRegions WHERE name = '" + textBox1.Text + "'", con);
                    adpt.Fill(tab);
                    dataGridView2.DataSource = tab;
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                tab = new DataTable();
                con.Open();
                adpt = new SqlDataAdapter("SELECT * from displayRegions ORDER BY name ASC; ", con);
                adpt.Fill(tab);
                dataGridView2.DataSource = tab;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void sort_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * from displayCities ORDER BY name ASC; ", con);
                    adpt.Fill(tab);
                    dataGridView1.DataSource = tab;
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * from displayCities WHERE name = '" + textBox1.Text + "ORDER BY name ASC'", con);
                    adpt.Fill(tab);
                    dataGridView1.DataSource = tab;
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                displayIslands();
            }
            else
            {
                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * from displayIslands WHERE name = '" + textBox2.Text + "'", con);
                    adpt.Fill(tab);
                    dataGridView3.DataSource = tab;
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * from displayIslands ORDER BY name", con);
                    adpt.Fill(tab);
                    dataGridView3.DataSource = tab;
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                try
                {
                    tab = new DataTable();
                    con.Open();
                    adpt = new SqlDataAdapter("SELECT * from displayIslands ORDER BY name ", con);
                    adpt.Fill(tab);
                    dataGridView3.DataSource = tab;
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
